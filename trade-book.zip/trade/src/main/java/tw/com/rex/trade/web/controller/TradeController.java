package tw.com.rex.trade.web.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/trade")
public class TradeController {

    @PostMapping("/income")
    public ResponseEntity<Boolean> income() {
        return ResponseEntity.ok(Boolean.TRUE);
    }

}
