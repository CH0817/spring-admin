# Trade Book

Spring Boot + Cloud 練習

## Modules

1. eureka, port: 9100
2. gateway, port: 9200